package br.ifsul.bdii.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import java.awt.Color;

public class Cadastro extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblLogin;
	private JTextField Nome;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JPasswordField pwdSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Cadastro frame = new Cadastro();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Cadastro() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 900);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
			
		JPanel panel = new JPanel(); //painel principal
		panel.setBackground(new Color(173, 177, 245));
		panel.setBounds(243, 251, 715, 430);
		contentPane.add(panel);
		panel.setLayout(null);
		
		Nome = new JTextField("Nome: "); // campo de nome
		Nome.setBounds(23, 72, 308, 44);
		panel.add(Nome);
		Nome.setColumns(10);
		
		textField_5 = new JTextField("Sobrenome: ");
		textField_5.setBounds(390, 72, 308, 44);
		panel.add(textField_5);
		textField_5.setColumns(10);
		
		pwdSenha = new JPasswordField();
		pwdSenha.setBounds(23, 138, 675, 44);
		panel.add(pwdSenha);
		pwdSenha.setText("Teste");
		
		textField_4 = new JTextField("Numero de telefone: ");
		textField_4.setBounds(23, 204, 675, 44);
		panel.add(textField_4);
		textField_4.setColumns(10);
		
		textField_2 = new JTextField("CRM (opcional)");
		textField_2.setBounds(23, 343, 675, 44);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField("CPF: ");
		textField_3.setBounds(23, 270, 675, 44);
		panel.add(textField_3);
		textField_3.setColumns(10);

		
	}
}
