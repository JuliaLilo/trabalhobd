package br.ifsul.bdii.domain;

public class Agenda {
	public Agenda(int idAgenda, String data, String localizacao, int idPessoa, int idMedico) {
		
		this.idAgenda = idAgenda;
		this.data = data;
		this.localizacao = localizacao;
		this.idPessoa = idPessoa;
		this.idMedico = idMedico;
	}
	private int idAgenda;
	private String data;
	private String localizacao;
	private int idPessoa;
	private int idMedico;
	public int getIdAgenda() {
		return idAgenda;
	}
	public void setIdAgenda(int idAgenda) {
		this.idAgenda = idAgenda;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getLocalizacao() {
		return localizacao;
	}
	public void setLocalizacao(String localizacao) {
		this.localizacao = localizacao;
	}
	public int getIdPessoa() {
		return idPessoa;
	}
	public void setIdPessoa(int idPessoa) {
		this.idPessoa = idPessoa;
	}
	public int getIdMedico() {
		return idMedico;
	}
	public void setIdMedico(int idMedico) {
		this.idMedico = idMedico;
	}
	@Override
	public String toString() {
		return "Agenda [idAgenda=" + idAgenda + ", data=" + data + ", localizacao=" + localizacao + ", idPessoa="
				+ idPessoa + ", idMedico=" + idMedico + "]";
	}
	

}
