package br.ifsul.bdii.domain;

public class Medico{
	public Medico(int idMedico, String nome, String sobrenome, String cpf, String crm, Boolean medicoPsicologo) {
	
		this.idMedico = idMedico;
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.cpf = cpf;
		this.crm = crm;
		this.medicoPsicologo = medicoPsicologo;
	}
	private int idMedico;
	private String nome;
	private String sobrenome;
	private String cpf;
	private String crm;
	private Boolean medicoPsicologo;
	public int getIdMedico() {
		return idMedico;
	}
	public void setIdMedico(int idMedico) {
		this.idMedico = idMedico;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSobrenome() {
		return sobrenome;
	}
	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getCrm() {
		return crm;
	}
	public void setCrm(String crm) {
		this.crm = crm;
	}
	public Boolean getMedicoPsicologo() {
		return medicoPsicologo;
	}
	public void setMedicoPsicologo(Boolean medicoPsicologo) {
		this.medicoPsicologo = medicoPsicologo;
	}
	@Override
	public String toString() {
		return "Medico [idMedico=" + idMedico + ", nome=" + nome + ", sobrenome=" + sobrenome + ", cpf=" + cpf
				+ ", crm=" + crm + ", medicoPsicologo=" + medicoPsicologo + "]";
	}

}
