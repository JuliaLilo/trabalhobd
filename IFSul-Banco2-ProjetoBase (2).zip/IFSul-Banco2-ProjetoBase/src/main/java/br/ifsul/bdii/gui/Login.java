package br.ifsul.bdii.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import java.awt.Color;
import java.awt.Font;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblLogin;
	private JTextField Nome;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JPasswordField pwdSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Login() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 900);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
			
		JPanel panel = new JPanel(); //painel principal
		panel.setBackground(new Color(173, 177, 245));
		panel.setBounds(243, 300, 715, 300);
		contentPane.add(panel);
		panel.setLayout(null);
		
		textField_3 = new JTextField("CPF: "); // campo do cpf
		textField_3.setBounds(20, 95, 675, 44);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		pwdSenha = new JPasswordField(); //campo de senha
		pwdSenha.setBounds(20, 161, 675, 44);
		panel.add(pwdSenha);
		pwdSenha.setText("Teste");
		
		JLabel lblNewLabel = new JLabel("Bem vindo novamente");
		lblNewLabel.setFont(new Font("Franklin Gothic Book", Font.PLAIN, 20));
		lblNewLabel.setBounds(27, 42, 209, 24);
		panel.add(lblNewLabel);
		
	

		
	}
}