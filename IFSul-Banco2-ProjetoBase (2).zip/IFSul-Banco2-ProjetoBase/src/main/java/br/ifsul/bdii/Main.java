package br.ifsul.bdii;

import br.ifsul.bdii.gui.UICadastroPessoa;
import br.ifsul.bdii.gui.UILogin;

public class Main {

	public static void main(String[] args) {

		
		UICadastroPessoa uicp = new UICadastroPessoa();
		UILogin uilo = new UILogin();
		
		uicp.setVisible(true);
		uilo.setVisible(true);
	}
}
