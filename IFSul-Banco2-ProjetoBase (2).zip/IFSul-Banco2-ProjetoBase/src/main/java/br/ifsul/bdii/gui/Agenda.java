package br.ifsul.bdii.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPasswordField;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.ImageIcon;
import java.awt.Font;

public class Agenda extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JLabel lblLogin;
	private JTextField Nome;
	private JTextField textField_2;
	private JTextField textField_3;
	private JTextField textField_4;
	private JTextField textField_5;
	private JPasswordField pwdSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Agenda frame = new Agenda();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Agenda() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1200, 900);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
			
		JPanel panel = new JPanel(); //painel principal
		panel.setBackground(new Color(173, 177, 245));
		panel.setBounds(243, 251, 715, 430);
		contentPane.add(panel);
		panel.setLayout(null);
		
		textField_4 = new JTextField("Data e Hora: ");
		textField_4.setBounds(23, 140, 675, 44);
		panel.add(textField_4);
		textField_4.setColumns(10);
		
		textField_2 = new JTextField("Médico: ");
		textField_2.setBounds(23, 280, 675, 44);
		panel.add(textField_2);
		textField_2.setColumns(10);
		
		textField_3 = new JTextField("Local: ");
		textField_3.setBounds(23, 209, 675, 44);
		panel.add(textField_3);
		textField_3.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Agenda");
		lblNewLabel.setFont(new Font("Franklin Gothic Medium", Font.PLAIN, 20));
		lblNewLabel.setBounds(42, 32, 132, 18);
		panel.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\Julia\\Downloads\\file.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(987, 443, 50, 50);
		contentPane.add(btnNewButton);

		
	}
}
